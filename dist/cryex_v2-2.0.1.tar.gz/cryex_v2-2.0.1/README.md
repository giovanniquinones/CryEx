# CryEx

(This repository is private for now)

A Python pipeline to identify Cryptix exons from RNA-Seq data.
It uses Stringtie to assemble transcripts and identify cryptic exons. 
It then calculates the PSI of each cryptic exons

Instead of processing one bam file at the time, it takes as input a metadata
file (FOFN) and can processes multiple bam files at once. 


## Installation
Download this repository then:

```
git clone https://github.com/giovanniquinones/CryEx
cd CryEx

# create a virtual environment from yaml file
conda env create -f cryex_env.yaml
conda activate CryEx_env

# install the package
pip install .
export PATH=/path/to/bin:$PATH 
```

### Dependencies
- stringtie
- multiprocess
- numpy
- pandas
- pysam
- subprocess

## Usage

```
# check if installed successfully
CryEx_stringtie --help 

# identify cryptic and annotated exons
CryEx_stringtie -f ${FOFN.tsv} -o ${EXONS.GTF}


# calculate splice junction usage
CryEx_junctions -f ${FOFN.tsv} -o ${JXN.BED}


# calculate PSI
CryEx_psi_calculator -f ${FOFN.tsv} -e ${EXONS.GTF} -j ${JXN.BED.GZ} -o {PSI.TSV} 


# calculate diffential splicing
CryEx_diff -f ${FOFN.tsv} -p {PSI.TSV} -o {DIFF.tsv}
```

## Input

FOFN should be tab separated and have the following columns:
For differential splicing, Cryex will use the 'GROUP' column

```
SAMPLE	    BAM	                    STAR_SJ_OUT	                    GROUP
sample1    /path/to/sample1.bam 	/path/to/sample1.SJ.out.tab     CTRL
sample2    /path/to/sample2.bam 	/path/to/sample2.SJ.out.tab     KD
sample3    /path/to/sample3.bam 	/path/to/sample3.SJ.out.tab     CTRL
sample4	   /path/to/sample4.bam     /path/to/sample4.SJ.out.tab     KD
```

## Output
- CryEx_stringtie will output a standard GTF file with the identified cryptic and annotated exons.
- CryEx_junctions will output a BED file with the splice junctions and their usage.

```
chr21	9826943	    9826984	    hte1,hte2,hte3,hte4     10,1,7,11	+
chr21	9827330	    9874067	    hte1,hte2,hte3,hte4     1,0,0,0     +
chr21	9907492	    9908277	    hte1,hte2,hte3,hte4     63,47,35,49	-
chr21	9907462	    9909046	    hte1,hte2,hte3,hte4     1,0,0,0     -
chr21	9908432	    9909046	    hte1,hte2,hte3,hte4     12,19,11,8	-
```

- CryEx_psi_calculator will output a TSV file with the PSI values for each cryptic exon.

```
exon_type       chrom   exon_3ss    exon_5ss    strand  inclusion_n     exc_5ss exc_3ss exclusion_n SAMPLE  PSI
first_exon      chr21   9907191     9907492     -       97              9896772 9966321 1           r2      0.96
first_exon      chr21   9907191     9907492     -       67              9896772 9966321 0           r3      1.0
first_exon      chr21   9907191     9907492     -       99              9896772 9966321 0           r4      1.0
first_exon      chr21   9907191     9907492     -       97              9896772 9966321 3           r2      0.92
first_exon      chr21   9907191     9907492     -       67              9896772 9966321 0           r3      1.0
first_exon      chr21   9907191     9907492     -       99              9896772 9966321 0           r4      1.0
```
- CryEx_diff will output a TSV file with the differential splicing results.

```
exon_type	exon_coords	                flanking_jxns	    LLR     Pvalue	    Sig	    DeltaPSI    DIFF    PSIGroup1	PSIGroup2	CovGroup1	CovGroup2	Pvalue_Adj
last_exon	chr21:45458057-45462429:+	45457808,45472160	2.49	2.57e-02	True	-0.54	    ctrl-kd	0.01,0.02	0.56,0.54	238,219	    285,323	    1.00e+00
last_exon	chr21:45458057-45462454:+	45457808,45472160	2.49	2.57e-02	True	-0.54	    ctrl-kd	0.01,0.02	0.56,0.54	238,219	    285,323	    1.00e+00
first_exon	chr21:45514756-45516594:+	45514114,45518237	2.332	3.08e-02	True	-0.26	    ctrl-kd	0.02,0.02	0.2,0.36	206,210	    74,50	    1.00e+00
first_exon	chr21:45515067-45516594:+	45514114,45518237	2.332	3.08e-02	True	-0.28	    ctrl-kd	0.02,0.02	0.23,0.38	206,210	    74,50	    1.00e+00
middle_exon	chr21:45516486-45516594:+	45514114,45518237	2.332	3.08e-02	True	-0.48	    ctrl-kd	0.07,0.07	0.48,0.62	206,210	    74,50	    1.00e+00
middle_exon	chr21:47914042-47914146:+	47910632,47916900	2.408	2.82e-02	True	-0.71	    ctrl-kd	0.02,0.09	0.71,0.82	160,121	    168,173	    1.00e+00
```


